import json
import pickle
import random
import io
from PIL import Image
import os, math, numpy as np
os.environ["CUDA_VISIBLE_DEVICES"]="0"

import torch
from qwen_vl_utils import process_vision_info
from transformers import AutoProcessor
# from vllm import LLM, SamplingParams
import vllm
import os

# Важно для корректной работы многопроцессорности
# os.environ['VLLM_WORKER_MULTIPROC_METHOD'] = 'spawn'

def prepare_inputs_for_vllm(messages, processor):
    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    # Обработка визуальной информации (требуется qwen-vl-utils 0.0.14+)
    image_inputs, video_inputs, video_kwargs = process_vision_info(
        messages,
        image_patch_size=processor.image_processor.patch_size,
        return_video_kwargs=True,
        return_video_metadata=True
    )

    mm_data = {}
    if image_inputs is not None:
        mm_data['image'] = image_inputs
    if video_inputs is not None:
        mm_data['video'] = video_inputs

    return {
        'prompt': text,
        'multi_modal_data': mm_data,
        'mm_processor_kwargs': video_kwargs
    }

import base64
from PIL import Image
import io

def blob_to_image(blob_data):
    """
    Преобразование бинарных данных JPEG в изображение
    """
    try:
        # Создаем BytesIO объект из бинарных данных
        image_stream = io.BytesIO(blob_data)
        
        # Открываем изображение с помощью PIL
        image = Image.open(image_stream)
        
        return image
    except Exception as e:
        print(f"Ошибка при преобразовании blob в изображение: {e}")
        return None

def save_all_images(data):
    for i in range(len(data)):
        image = blob_to_image(data[i]['image'])
        image.save(f'image_{i}.jpg')

def format_answer(text):
        answer = ""
        for let in "ABCDEF":
            if let in text:
                answer += let
        if answer == '':
            for let in "abcdef":
                if let in text:
                    answer += let.upper()
        if answer == '':
            return "ABCD"
        return answer

import re

def extract_last_boxed(text: str) -> str | None:
    pattern = r'[A-F]+'
    matches = re.findall(pattern, text)
    return matches[-1] if matches else ''

# def majority_vote(preds):
#     """Берем буквы, встречающиеся хотя бы в двух из трёх предсказаний"""
#     counts = {let: sum(let in p for p in preds) for let in "ABCDEF"}
#     result = "".join([k for k, v in counts.items() if v >= 2])
#     if not result:
#         result = "".join(set(preds[0]) & set(preds[1]) & set(preds[2]))
#     if result == "":
#         result = "".join(set(preds[0]) & set(preds[1]))
#     if result == "":
#         result = preds[0]
#     return result

if __name__ == "__main__":
    checkpoint_path = "./qwen-3-vl-transformers-4b-instruct-v1"
    processor = AutoProcessor.from_pretrained(checkpoint_path)
    
    with open('input.pickle', "rb") as input_file:
        model_input = pickle.load(input_file)

    save_all_images(model_input)
    answers = ["A", "B", "C", "D", "AB", "BC", "CD", "ABC", "BCD", "ABCD"]

    model_output = []
    inputs = []
    ridx = []
    for i, row in enumerate(model_input):
        rid = row["rid"]
        question = row["question"]
        ridx.append(rid)
        sys_prompt = """You are an expert in analyzing technical diagrams and geometric figures.
        You are given an image and answer options. Study the image carefully. Your task is to choose one or more correct answers. Think step-by-step and be very breaf. Think no longer than 5 sentences per option!
        Focus ONLY on information that can be directly verified from the image.
        Put the letters of all the correct answers, without separating them in \\boxed{} at the end.
        For example, if B, C and D are correct, the final answer is \\boxed{BCD}."""
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "image": f"image_{i}.jpg",
                        # "resized_height": 128,
                        # "resized_width": 128,
                    },
                    {"type": "text", "text": question + "\n\n" + sys_prompt},
                ],
            }
        ]
        inputs.append(prepare_inputs_for_vllm(messages, processor))
        
        # image = Image.open(io.BytesIO(row["image"]))
        # w, h = image.getdata().size

        # your prediction here
        # prediction = 
        # model_output.append({"rid" : rid, "answer" : random.choice(answers)})
    llm = vllm.LLM(
        checkpoint_path,
        # quantization='awq',
        # "Qwen/Qwen3-4B-Thinking-2507", # Название модели на Hugging Face
        tensor_parallel_size=1, # Распараллеливание модели на 2 GPU
        gpu_memory_utilization=0.95, # Использование 95% памяти GPU
        trust_remote_code=True, # Разрешение выполнения кода из хаба модели
        dtype="half", # Использование 16-битной точности для ускорения
        enforce_eager=True, # Включение eager-режима
        max_model_len=5096, # Максимальная длина последовательности
    )
    N=5
    sampling_params = vllm.SamplingParams(
        # temperature=0.1,
        n=N,
        temperature=0.6,
        top_p=0.95,
        # top_k=20,
        max_tokens=5096,
        # presence_penalty=1.5,
        # repetition_penalty=1.0,
        seed=777 # 0
    )
    
    outputs = llm.generate(inputs, sampling_params=sampling_params)

    def get_consensus_prediction(outputs, N, threshold=0.6):
        """
        Получает консенсусный ответ из N выводов модели
        
        Args:
            outputs: список выводов модели
            N: количество выводов
            threshold: порог для выбора большинства
        
        Returns:
            consensus_text: консенсусный ответ
        """
        # Извлекаем все ответы с boxed
        boxed_answers = []
        all_answers = []
        
        for i in range(N):
            text = outputs[i].text
            all_answers.append(text)
            boxed_answer = extract_last_boxed(text)
            if "boxed" in text and boxed_answer:  # Проверяем наличие boxed и что извлечение не пустое
                boxed_answers.append((i, boxed_answer))
        
        # Если нет ответов с boxed, используем все ответы
        if not boxed_answers:
            candidates = [extract_last_boxed(text) for text in all_answers]
        else:
            # Используем только ответы с boxed
            candidate_indices, candidates = zip(*boxed_answers)
        
        # Проверяем наличие ответа, который встречается в строго более чем threshold доле
        candidate_count = {}
        for candidate in candidates:
            candidate_count[candidate] = candidate_count.get(candidate, 0) + 1
        
        total_candidates = len(candidates)
        for candidate, count in candidate_count.items():
            if count / total_candidates > threshold:
                return candidate
        
        # Если нет явного большинства, берем пересечение всех ответов с boxed
        if boxed_answers:
            candidate_sets = [set(candidate) for candidate in candidates]
            
            # Сначала пробуем полное пересечение всех ответов
            intersection = set.intersection(*candidate_sets)
            if intersection:
                return "".join(intersection)
            
            # Если полного пересечения нет, пробуем пересечения по парам
            # Сортируем пары по убыванию размера пересечения
            pairs = []
            for i in range(len(candidate_sets)):
                for j in range(i + 1, len(candidate_sets)):
                    pair_intersection = candidate_sets[i] & candidate_sets[j]
                    if pair_intersection:
                        pairs.append((len(pair_intersection), i, j, pair_intersection))
            
            # Сортируем по размеру пересечения (от большего к меньшему)
            pairs.sort(key=lambda x: x[0], reverse=True)
            
            # Возвращаем первое непустое пересечение
            for _, i, j, intersection in pairs:
                if intersection:
                    return "".join(intersection)
        
        # Если пересечение пустое или нет ответов с boxed, выбираем самый частый ответ
        if candidate_count:
            # Выбираем кандидата с максимальной частотой
            most_common = max(candidate_count.items(), key=lambda x: x[1])
            return most_common[0]
        
        # Если все остальное не сработало, берем первый ответ
        return extract_last_boxed(all_answers[0])
    
    
    preds = []
    for output in outputs:
        print("\n".join([f"Output {i}:\n{out.text}" for i, out in enumerate(output.outputs)]), end='\n----\n')
        
        generated_text = get_consensus_prediction(output.outputs, N)
        preds.append(generated_text)
    
    # preds = []
    # for output in outputs:
    #     print(output.outputs[0].text, end='\n----\n')
    #     print(output.outputs[1].text, end='\n----\n')
    #     print(output.outputs[2].text, end='\n----\n')
    #     generated_text = "".join(set(extract_last_boxed(output.outputs[0].text)) & set(extract_last_boxed(output.outputs[1].text)) & set(extract_last_boxed(output.outputs[2].text)))
    #     # preds.append(format_answer(generated_text))
    #     if generated_text == "":
    #         generated_text = "".join(set(extract_last_boxed(output.outputs[0].text)) & set(extract_last_boxed(output.outputs[1].text)))
    #     if generated_text == "":
    #         generated_text = "".join(set(extract_last_boxed(output.outputs[2].text)) & set(extract_last_boxed(output.outputs[1].text)))
    #     if generated_text == "":
    #         generated_text = "".join(set(extract_last_boxed(output.outputs[0].text)) & set(extract_last_boxed(output.outputs[2].text)))
    #     if generated_text == "":
    #         if "boxed" in output.outputs[0].text:
    #             generated_text = extract_last_boxed(output.outputs[0].text)
    #         elif "boxed" in output.outputs[1].text:
    #             generated_text = extract_last_boxed(output.outputs[1].text)
    #         elif "boxed" in output.outputs[2].text:
    #             generated_text = extract_last_boxed(output.outputs[2].text)
    #         else:
    #             generated_text = extract_last_boxed(output.outputs[0].text)
    #     # generated_text = majority_vote([extract_last_boxed(output.outputs[0].text), extract_last_boxed(output.outputs[1].text), extract_last_boxed(output.outputs[2].text)])
    #     preds.append(generated_text)

    print(preds)
    
    for rid, pred in zip(ridx, preds):
        model_output.append({"rid" : rid, "answer": pred})
    
    with open('output.json', 'w') as output_file:
        json.dump(model_output, output_file, ensure_ascii=False)
